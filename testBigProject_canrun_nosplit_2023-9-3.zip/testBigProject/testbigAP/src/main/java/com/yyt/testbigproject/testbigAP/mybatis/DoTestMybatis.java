package com.yyt.testbigproject.testbigAP.mybatis;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.yyt.testbigproject.testbigAP.mybatis.mapper.ComponentMapper;
import com.yyt.testbigproject.testbigAP.mybatis.pojo.Component;

public class DoTestMybatis {

	public void TestSqlSession() throws IOException {
		//1. 加载mybatis的核心配置文件，获取 SqlSessionFactory
    	String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //2. 获取SqlSession对象，用它来执行sql
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //3. 执行sql
        ComponentMapper componentMapper = sqlSession.getMapper(ComponentMapper.class);
        List<Component> tts = componentMapper.selectAll();
        Component fT = componentMapper.selectById("	 ('fc0f15cc-2176-40b5-b04f-8b409151f937'");
        Component nff = new Component();
        nff.setID("ahahhhhhhasdfasdfasdf");
        nff.setNAME("fh");
        nff.setPARENT_ID("adsfafadsf314334");
        nff.setPROVIDER_ID("132413241234");
        nff.setPROVIDER_TYPE("A");
        nff.setREALM_ID("asdfasdfasdfasdf");
        nff.setSUB_TYPE("asfasdf132413241");
        componentMapper.add(nff);
        sqlSession.commit();
        System.out.println(tts);
        System.out.println(fT);
        //4. 释放资源
        sqlSession.close();
	}
	
	public List<Component> ListAll() throws IOException {
		//1. 加载mybatis的核心配置文件，获取 SqlSessionFactory
    	String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //2. 获取SqlSession对象，用它来执行sql
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //3. 执行sql
        ComponentMapper componentMapper = sqlSession.getMapper(ComponentMapper.class);
        List<Component> tts = componentMapper.selectAll();
        return tts;
	}
}
