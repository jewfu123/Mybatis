package com.yyt.testbigproject.parentproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParentprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
