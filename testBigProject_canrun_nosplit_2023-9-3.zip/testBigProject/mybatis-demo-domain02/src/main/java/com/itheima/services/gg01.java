package com.itheima.services;

import java.io.IOException;

import org.springframework.ui.Model;

public interface gg01 {
	
	void Hellome(Model model);

	void getListAll(Model model) throws IOException;
}
