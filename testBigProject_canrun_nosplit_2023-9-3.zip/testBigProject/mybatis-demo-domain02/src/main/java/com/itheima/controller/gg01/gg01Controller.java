package com.itheima.controller.gg01;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.itheima.services.gg01;
import com.yyt.testbigproject.testbigAP.mybatis.DoTestMybatis;
import com.itheima.mapper.ComponentMapper;
//import com.yyt.testbigproject.testbigAP.mybatis.DoTestMybatis;
import com.itheima.pojo.Component;

@Controller
public class gg01Controller {

	//@Autowired
	//private gg01 service;
	
	@GetMapping("/hellome")
	public String Hellome(Model model) {
		model.addAttribute("message", "Hello Thymeleaf!!!");
		HashMap<String, String> inputMap = new HashMap<>();
		inputMap.put("name", "jewfu");
		inputMap.put("age", "18");
		inputMap.put("address", "Japan Tokyo");
		model.addAttribute("info", inputMap);
		//service.Hellome(model);
		return "hello";
	}
	
	@GetMapping("/listall")
	public String ListAll(Model model) throws IOException {
		//DoTestMybatis ddt = new DoTestMybatis();
    	List<Component> td = this.ListAll();
    	model.addAttribute("showBody", td);
    	System.out.println(td);
		//service.getListAll(model);
		return "showlist";
	}
	
	public List<Component> ListAll() throws IOException {
		//1. 加载mybatis的核心配置文件，获取 SqlSessionFactory
    	String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //2. 获取SqlSession对象，用它来执行sql
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //3. 执行sql
        ComponentMapper componentMapper = sqlSession.getMapper(ComponentMapper.class);
        List<Component> tts = componentMapper.selectAll();
        return tts;
	}
}
