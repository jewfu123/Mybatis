package com.itheima.services.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.springframework.ui.Model;

import com.itheima.mapper.ComponentMapper;
import com.itheima.pojo.Component;
import com.itheima.services.gg01;

public class gg01Impl implements gg01 {

	@Override
	public void getListAll(Model model) throws IOException {
		//DoTestMybatis ddt = new DoTestMybatis();
		ComponentMapper cMapper = null;
    	List<Component> td = cMapper.selectAll();
    	model.addAttribute("showBody", td);
    	System.out.println(td);
	}

	@Override
	public void Hellome(Model model) {
		HashMap<String, String> inputMap = new HashMap<>();
		inputMap.put("name", "jewfu");
		inputMap.put("age", "18");
		inputMap.put("address", "Japan Tokyo");
		model.addAttribute("info", inputMap);
	}
	
}
