package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.ResponseBody;

@SpringBootApplication
//@ComponentScan({"com.itheima.services"})
public class mybatisDemoApplication {
	
	public static void main(String[] args) {
	  SpringApplication.run(mybatisDemoApplication.class, args);
	}
	
}
