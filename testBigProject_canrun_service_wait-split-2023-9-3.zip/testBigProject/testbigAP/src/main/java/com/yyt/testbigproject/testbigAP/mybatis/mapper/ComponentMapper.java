package com.yyt.testbigproject.testbigAP.mybatis.mapper;

import java.util.List;

import com.yyt.testbigproject.testbigAP.mybatis.pojo.Component;

public interface ComponentMapper {
	
	List<Component> selectAll();
	
	/**
     * 添加
     */
    void add(Component component);
    
    /**
     * 查看详情：根据Id查询
     */
    Component selectById(String id);

}
