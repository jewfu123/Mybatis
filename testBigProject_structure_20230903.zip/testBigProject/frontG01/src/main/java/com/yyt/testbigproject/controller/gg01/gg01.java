package com.yyt.testbigproject.controller.gg01;

@Controller
@RequestMapping("/front")
public class gg01 {

}
