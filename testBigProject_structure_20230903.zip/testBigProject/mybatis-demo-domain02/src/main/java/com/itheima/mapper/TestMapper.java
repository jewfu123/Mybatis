package com.itheima.mapper;

import java.util.List;

import com.itheima.pojo.Brand;

public interface TestMapper {
	List<Brand> selectAll();
}
