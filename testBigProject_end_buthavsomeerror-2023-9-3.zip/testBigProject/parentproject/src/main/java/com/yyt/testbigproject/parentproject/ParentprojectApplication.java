package com.yyt.testbigproject.parentproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentprojectApplication.class, args);
	}

}
