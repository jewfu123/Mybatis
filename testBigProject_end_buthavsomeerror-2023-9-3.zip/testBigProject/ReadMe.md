## Summary ##

####1. Multiful modules for a project is for more and more persons work together.

####2. This big project include:

######(1) baseAP 			[ Common ]

######(2) frontG011 		[ Front ]

######(3) endDomain02 		[ End ]

######(4) parentProject 	[ base Functions ]

	
####3. about pom structor in project:

######(1) group is deferent from inheritent.

######(2) in my projects, controller with services commution has some wrong and have not found the error....